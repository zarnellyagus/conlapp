import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private apiUrl = 'https://localhost:7067/api';

  constructor(private http: HttpClient) {}

  getConsolidatePolicies(policyId?: string, appNo?: string, page: number = 1, pageSize: number = 10): Observable<any[]> {
    let params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString());
    
    if (policyId) params = params.set('policyId', policyId);
    if (appNo) params = params.set('appNo', appNo);

    return this.http.get<any[]>(`${this.apiUrl}/consolidatepolicy`, { params });
  }

  getPolicyInfo(policyId: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/consolidatepolicy/${policyId}/info`);
  }

  getPolicyEPolicy(policyId: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/consolidatepolicy/${policyId}/epolicy`);
  }

  getPolicySummary(policyId: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/consolidatepolicy/${policyId}/summary`);
  }
}
