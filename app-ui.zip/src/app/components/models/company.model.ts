export interface Company {
  companyID: string;
  companyName: string;
  isDefault?: boolean;
  isActive?: boolean;
}