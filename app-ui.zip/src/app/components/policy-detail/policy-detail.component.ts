import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../../services/data.service';

@Component({
  selector: 'app-policy-detail',
  standalone:false,
  templateUrl: './policy-detail.component.html',
  styleUrls: ['./policy-detail.component.css']
})
export class PolicyDetailComponent implements OnInit {
  policyId: string = '';
  activeTab: string = 'policy-info';
  isLoading: boolean = false;
  
  // Policy Info Data
  policyInfo: any = null;
  
  // E-Policy Data
  epolicyData: any[] = [];
  
  // Policy Summary Data
  policySummary: any[] = [];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private dataService: DataService
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.policyId = params['id'];
      if (this.policyId) {
        this.loadPolicyData();
      }
    });
  }

  loadPolicyData(): void {
    this.isLoading = true;
    this.loadPolicyInfo();
    this.loadEPolicyData();
    this.loadPolicySummary();
  }

  loadPolicyInfo(): void {
    this.dataService.getPolicyInfo(this.policyId).subscribe({
      next: (data) => {
        this.policyInfo = data;
        this.checkLoadingComplete();
      },
      error: (error) => {
        console.error('Error loading policy info:', error);
        this.checkLoadingComplete();
      }
    });
  }

  loadEPolicyData(): void {
    this.dataService.getPolicyEPolicy(this.policyId).subscribe({
      next: (data) => {
        this.epolicyData = data;
        this.checkLoadingComplete();
      },
      error: (error) => {
        console.error('Error loading e-policy data:', error);
        this.checkLoadingComplete();
      }
    });
  }

  loadPolicySummary(): void {
    this.dataService.getPolicySummary(this.policyId).subscribe({
      next: (data) => {
        this.policySummary = data;
        this.checkLoadingComplete();
      },
      error: (error) => {
        console.error('Error loading policy summary:', error);
        this.checkLoadingComplete();
      }
    });
  }

  private loadingCount = 0;
  checkLoadingComplete(): void {
    this.loadingCount++;
    if (this.loadingCount >= 3) {
      this.isLoading = false;
    }
  }

  setActiveTab(tab: string): void {
    this.activeTab = tab;
  }

  goBack(): void {
    this.router.navigate(['/consolidate-policy']);
  }

  formatDate(date: any): string {
    if (!date) return '-';
    return new Date(date).toLocaleDateString('id-ID');
  }
}
