import { Component, OnInit } from '@angular/core';
import { AuthService, MenuObject } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  standalone:false,
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  currentUser: any;
  menus: MenuObject[] = [];
  sidebarOpen: boolean = true;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.currentUser = this.authService.getCurrentUser();
    if (this.currentUser.userID) {
      this.loadUserMenus();
    }
  }

  loadUserMenus(): void {
    this.authService.getUserMenus(this.currentUser.userID, this.currentUser.companyID).subscribe({
      next: (menus) => {
        this.menus = menus;
      },
      error: (error) => {
        console.error('Error loading menus:', error);
      }
    });
  }

  toggleSidebar(): void {
    this.sidebarOpen = !this.sidebarOpen;
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  navigateToConsolidatePolicy(): void {
    this.router.navigate(['/consolidate-policy']);
  }
}
