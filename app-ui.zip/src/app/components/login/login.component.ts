// login.component.ts
import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { Company } from '../models/company.model';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-login',
  standalone:false,
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {
  loginForm!: FormGroup;
  companies: Company[] = [];
  defaultCompany: Company | null = null;
  errorMessage: string = '';
  successMessage: string = '';
  isLoading: boolean = false;
  showPassword: boolean = false;
  
  private subscriptions: Subscription = new Subscription();

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.initializeForm();
  }

  ngOnInit(): void {
    document.body.classList.add('login-page');
    document.documentElement.classList.add('login-page');
    
    this.loadCompanies();
    
    if (this.authService.isLoggedIn()) {
      this.router.navigate(['/dashboard']);
    }
  }

  ngOnDestroy(): void {
    document.body.classList.remove('login-page');
    document.documentElement.classList.remove('login-page');
    this.subscriptions.unsubscribe();
  }

  private initializeForm(): void {
    this.loginForm = this.fb.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required]],
      companyID: ['', [Validators.required]],
      rememberMe: [false]
    });
  }

  loadCompanies(): void {
    this.isLoading = true;
    
    this.subscriptions.add(
      this.authService.getCompanies().subscribe({
        next: (companies: Company[]) => {
          this.companies = companies;
          
          // Find default company
          this.defaultCompany = companies.find(c => c.isDefault) || companies[0] || null;
          
          // Set default company in form
          this.setDefaultCompanyInForm();
          
          // Load remembered credentials after companies are loaded
          this.loadRememberedCredentials();
          
          this.isLoading = false;
        },
        error: (error: any) => {
          console.error('Error loading companies:', error);
          this.errorMessage = 'Failed to load companies. Please refresh the page.';
          this.isLoading = false;
        }
      })
    );
  }

  private setDefaultCompanyInForm(): void {
    if (this.defaultCompany) {
      this.loginForm.patchValue({
        companyID: this.defaultCompany.companyID
      });
    }
  }

  private loadRememberedCredentials(): void {
    if (localStorage.getItem('rememberMe') === 'true') {
      const lastUsername = localStorage.getItem('lastUsername');
      const lastCompany = localStorage.getItem('lastCompany');
      
      // Verify that the remembered company still exists
      const companyExists = this.companies.find(c => c.companyID === lastCompany);
      
      if (lastUsername) {
        this.loginForm.patchValue({
          username: lastUsername,
          rememberMe: true
        });
      }

      if (companyExists) {
        this.loginForm.patchValue({
          companyID: lastCompany
        });
      }
    }
  }

  // Method yang missing - tambahkan ini
  isDefaultCompany(company: Company): boolean {
    return this.defaultCompany?.companyID === company.companyID;
  }

  togglePasswordVisibility(): void {
    this.showPassword = !this.showPassword;
  }

  onSubmit(): void {
    if (this.loginForm.valid) {
      this.isLoading = true;
      this.errorMessage = '';
      this.successMessage = '';
      
      const loginData = {
        username: this.loginForm.value.username,
        password: this.loginForm.value.password,
        companyID: this.loginForm.value.companyID
      };
      
      this.subscriptions.add(
        this.authService.login(loginData).subscribe({
          next: (response: any) => {
            if (response.success) {
              this.successMessage = 'Login successful! Redirecting...';
              
              // Handle remember me
              if (this.loginForm.value.rememberMe) {
                localStorage.setItem('rememberMe', 'true');
                localStorage.setItem('lastUsername', this.loginForm.value.username);
                localStorage.setItem('lastCompany', this.loginForm.value.companyID);
              } else {
                localStorage.removeItem('rememberMe');
                localStorage.removeItem('lastUsername');
                localStorage.removeItem('lastCompany');
              }
              
              setTimeout(() => {
                this.router.navigate(['/dashboard']);
              }, 1500);
            } else {
              this.errorMessage = response.message || 'Login failed. Please try again.';
            }
            this.isLoading = false;
          },
          error: (error: any) => {
            console.error('Login error:', error);
            this.errorMessage = 'Login failed. Please check your credentials and try again.';
            this.isLoading = false;
          }
        })
      );
    } else {
      this.markFormGroupTouched();
    }
  }

  private markFormGroupTouched(): void {
    Object.keys(this.loginForm.controls).forEach(key => {
      this.loginForm.get(key)?.markAsTouched();
    });
  }

  clearErrorMessage(): void {
    this.errorMessage = '';
  }

  getFormControl(controlName: string) {
    return this.loginForm.get(controlName);
  }

  hasError(controlName: string, errorType: string): boolean {
    const control = this.loginForm.get(controlName);
    return control ? control.hasError(errorType) && control.touched : false;
  }

  forgotPassword(event: Event): void {
    event.preventDefault();
    console.log('Forgot password clicked');
  }

  contactSupport(event: Event): void {
    event.preventDefault();
    console.log('Contact support clicked');
  }

  // Logo handling methods
  onLogoLoad(): void {
    console.log('✅ Company logo loaded successfully');
  }

  showLogoFallback(event: any): void {
    console.log('❌ Company logo failed to load, showing SVG fallback');
    const img = event.target;
    const fallback = img.nextElementSibling;
    
    if (img) img.style.display = 'none';
    if (fallback) fallback.style.display = 'block';
  }

  showMobileLogoFallback(event: any): void {
    console.log('❌ Mobile logo failed to load, showing SVG fallback');
    const img = event.target;
    const fallback = img.nextElementSibling;
    
    if (img) img.style.display = 'none';
    if (fallback) fallback.style.display = 'block';
  }
}
