import { Component, OnInit } from '@angular/core';
import { DataService } from '../../services/data.service';
import { Router } from '@angular/router';


import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { AuthService, Company } from '../../services/auth.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-consolidate-policy',
  standalone:false,
  templateUrl: './consolidate-policy.component.html',
  styleUrls: ['./consolidate-policy.component.css']
})
export class ConsolidatePolicyComponent implements OnInit {
  policies: any[] = [];
  searchPolicyId: string = '';
  searchAppNo: string = '';
  currentPage: number = 1;
  pageSize: number = 10;
  pageSizes: number[] = [10, 25, 50, 100];
  isLoading: boolean = false;

  constructor(
    private dataService: DataService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadPolicies();
  }

  loadPolicies(): void {
    this.isLoading = true;
    const policyId = this.searchPolicyId || undefined;
    const appNo = this.searchAppNo || undefined;

    this.dataService.getConsolidatePolicies(policyId, appNo, this.currentPage, this.pageSize)
      .subscribe({
        next: (policies) => {
          this.policies = policies;
          this.isLoading = false;
        },
        error: (error) => {
          console.error('Error loading policies:', error);
          this.isLoading = false;
        }
      });
  }

  onSearch(): void {
    this.currentPage = 1;
    this.loadPolicies();
  }

  onPageSizeChange(): void {
    this.currentPage = 1;
    this.loadPolicies();
  }

  nextPage(): void {
    this.currentPage++;
    this.loadPolicies();
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.loadPolicies();
    }
  }

  viewPolicyDetail(policyId: string): void {
    this.router.navigate(['/policy-detail', policyId]);
  }
}
