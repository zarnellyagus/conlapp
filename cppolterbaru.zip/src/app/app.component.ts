// app.component.ts
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  standalone: false,
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
  // HAPUS BARIS INI JIKA ADA: standalone: true
})
export class AppComponent {
  title = 'PolicyManagementFrontend';
}