// app/app.routes.ts
import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { 
    path: 'login', 
    loadComponent: () => import('./components/login/login.component').then(m => m.LoginComponent) 
  },
  { 
    path: 'dashboard', 
    loadComponent: () => import('./components/dashboard/dashboard.component').then(m => m.DashboardComponent) 
  },
  { 
    path: 'consolidate-policy', 
    loadComponent: () => import('./components/consolidate-policy/consolidate-policy.component').then(m => m.ConsolidatePolicyComponent) 
  },
  { 
    path: 'policy-detail/:id', 
    loadComponent: () => import('./components/policy-detail/policy-detail.component').then(m => m.PolicyDetailComponent) 
  }
];
