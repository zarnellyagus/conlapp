// services/auth.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';

export interface LoginRequest {
  username: string;
  password: string;
  company: string;
}

export interface LoginResponse {
  success: boolean;
  message: string;
  userID?: string;
  companyID?: string;
}

export interface Company {
  companyID: string;
  companyName: string;
}

export interface MenuObject {
  objectid: string;
  objectName: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'https://localhost:7185/api';
  private currentUserSubject = new BehaviorSubject<any>(null);
  public currentUser$ = this.currentUserSubject.asObservable();
  private redirectUrl: string = '/dashboard/home'; // Default redirect URL

  constructor(private http: HttpClient) {
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
      this.currentUserSubject.next(JSON.parse(savedUser));
    }
  }

  login(credentials: LoginRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.apiUrl}/auth/login`, credentials);
  }

  getCompanies(): Observable<Company[]> {
    return this.http.get<Company[]>(`${this.apiUrl}/auth/companies`);
  }

  getUserMenus(userId: string, companyId: string): Observable<MenuObject[]> {
    return this.http.get<MenuObject[]>(`${this.apiUrl}/auth/menus/${userId}/${companyId}`);
  }

  logout(): void {
    localStorage.removeItem('currentUser');
    this.currentUserSubject.next(null);
    this.redirectUrl = '/dashboard/home'; // Reset redirect URL
  }

  setCurrentUser(user: any): void {
    localStorage.setItem('currentUser', JSON.stringify(user));
    this.currentUserSubject.next(user);
  }

  getCurrentUser(): any {
    return this.currentUserSubject.value;
  }

  isLoggedIn(): boolean {
    return !!this.getCurrentUser();
  }

  // TAMBAHKAN METHODS INI YANG MISSING
  setRedirectUrl(url: string): void {
    this.redirectUrl = url;
  }

  getRedirectUrl(): string {
    const url = this.redirectUrl;
    this.redirectUrl = '/dashboard/home'; // Reset setelah digunakan
    return url;
  }
}
