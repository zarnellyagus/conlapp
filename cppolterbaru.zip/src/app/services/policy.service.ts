// services/policy.service.ts

import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

// ==================== EXPORT INTERFACES ====================

export interface ConsolidatePolicy {
  policyID: string;
  companyID: string;
  appNo: string;
  ownerName: string;
  insuredName: string;
  planName: string;
  issuedDate: string | Date;
}

export interface PolicyDetail {
  policyId: string;
  companyId: string;
  applicationNo: string;
   spajNo: string;
   policyNo:string;
   clientID:string;
  policyType: string;
  productName: string;
  planName: string;
  ownerName: string;
  ownerAddress: string;
  ownerPhone: string;
  ownerEmail: string;
  insuredName: string;
  insuredAddress: string;
  insuredPhone: string;
  insuredEmail: string;
  insuredDateOfBirth: string | Date;
  insuredGender: string;
  beneficiaryName: string;
  beneficiaryRelation: string;
  premiumAmount: number;
  coverageAmount: number;
  policyTerm: number;
  premiumTerm: number;
  issuedDate: string | Date;
  startDate: string | Date;
  endDate: string | Date;
  nextPremiumDue: string | Date;
  policyStatus: string;
  agentCode: string;
  agentName: string;
  branchCode: string;
  branchName: string;
  remarks: string;
  createdBy: string;
  createdDate: string | Date;
  lastModifiedBy: string;
  lastModifiedDate: string | Date;
}

export interface EpolicyInfo {
  policyId: string;
  epolicyStatus: string;
  epolicyNumber: string;
  generatedDate: string | Date;
  downloadUrl: string;
  isEmailSent: boolean;
  emailSentDate: string | Date;
  recipientEmail: string;
  documentSize: number;
  documentFormat: string;
  digitalSignature: boolean;
  qrCode: string;
  verificationCode: string;
  expiryDate: string | Date;
  downloadCount: number;
  lastDownloadDate: string | Date;
  isActive: boolean;
  createdBy: string;
  createdDate: string | Date;
  lastModifiedBy: string;
  lastModifiedDate: string | Date;
}

export interface PolicySummary {
  policyId: string;
  totalPremiumPaid: number;
  totalPremiumDue: number;
  nextPaymentAmount: number;
  nextPaymentDate: string | Date;
  policyValue: number;
  surrenderValue: number;
  loanValue: number;
  outstandingLoan: number;
  bonusAmount: number;
  paidUpValue: number;
  maturityAmount: number;
  maturityDate: string | Date;
  yearsToMaturity: number;
  premiumFrequency: string;
  lastPremiumPaidDate: string | Date;
  lastPremiumAmount: number;
  gracePeriodEnd: string | Date;
  policyLapseDate: string | Date;
  reinstatementEligible: boolean;
  dividendAmount: number;
  dividendOption: string;
}

export interface ApiPaginationResponse {
  data: any[];
  totalRecords: number;
  currentPage: number;
  pageSize: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}

// ==================== SERVICE ====================

@Injectable({
  providedIn: 'root'
})
export class PolicyService {
  private apiUrl = 'https://localhost:7185/api/policy/consolidate';
  private policyDetailUrl = 'https://localhost:7185/api/policy/detail';
  private epolicyUrl = 'https://localhost:7185/api/policy/epolicy';
  private policySummaryUrl = 'https://localhost:7185/api/policy/summary';

  constructor(private http: HttpClient) {}

  // ==================== CONSOLIDATE POLICIES ====================
  
  getConsolidatePolicies(policyId?: string, appNo?: string, page: number = 1, pageSize: number = 10): Observable<ApiPaginationResponse> {
    console.log('\n📡 === API SERVICE CALL ===');
    
    const params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString())
      .set('policyId', policyId || '')
      .set('appNo', appNo || '');

    console.log('Request URL:', this.apiUrl);
    console.log('Request params:', {
      page,
      pageSize,
      policyId: policyId || 'none',
      appNo: appNo || 'none'
    });

    return this.http.get<any>(this.apiUrl, { 
      params, 
      observe: 'response',
      headers: new HttpHeaders({
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      })
    }).pipe(
      map(response => {
        console.log('📥 Raw API Response:', {
          status: response.status,
          headers: this.logHeaders(response.headers),
          bodyType: typeof response.body,
          bodyPreview: Array.isArray(response.body) ? `Array[${response.body.length}]` : response.body
        });
        
        return this.processRealApiResponse(response, page, pageSize);
      }),
      catchError(error => {
        console.error('❌ API call failed:', error);
        return throwError(() => ({
          userMessage: this.getUserFriendlyErrorMessage(error),
          originalError: error,
          status: error.status
        }));
      })
    );
  }

  // ==================== POLICY DETAIL - API ONLY ====================
  
  getPolicyDetail(policyId: string): Observable<PolicyDetail> {
    console.log('📋 Getting policy detail for:', policyId);
    
    if (!policyId || policyId.trim() === '') {
      return throwError(() => ({ userMessage: 'Policy ID is required' }));
    }

    const url = `${this.policyDetailUrl}/${policyId}`;
    
    return this.http.get<PolicyDetail>(url, {
      headers: new HttpHeaders({
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      })
    }).pipe(
      map(response => {
        console.log('✅ Policy detail received:', response);
        return response;
      }),
      catchError(error => {
        console.error('❌ Get policy detail failed:', error);
        return throwError(() => ({
          userMessage: this.getUserFriendlyErrorMessage(error),
          originalError: error
        }));
      })
    );
  }

  // ==================== EPOLICY INFO - API ONLY ====================
  
  getEpolicyInfo(policyId: string): Observable<EpolicyInfo> {
    console.log('📋 Getting epolicy info for:', policyId);
    
    if (!policyId || policyId.trim() === '') {
      return throwError(() => ({ userMessage: 'Policy ID is required for epolicy info' }));
    }

    const url = `${this.epolicyUrl}/${policyId}`;
    
    return this.http.get<EpolicyInfo>(url, {
      headers: new HttpHeaders({
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      })
    }).pipe(
      map(response => {
        console.log('✅ Epolicy info received:', response);
        return response;
      }),
      catchError(error => {
        console.error('❌ Get epolicy info failed:', error);
        return throwError(() => ({
          userMessage: this.getUserFriendlyErrorMessage(error),
          originalError: error
        }));
      })
    );
  }

  // ==================== POLICY SUMMARY - API ONLY ====================
  
  getPolicySummary(policyId: string): Observable<PolicySummary> {
    console.log('📋 Getting policy summary for:', policyId);
    
    if (!policyId || policyId.trim() === '') {
      return throwError(() => ({ userMessage: 'Policy ID is required for summary' }));
    }

    const url = `${this.policySummaryUrl}/${policyId}`;
    
    return this.http.get<PolicySummary>(url, {
      headers: new HttpHeaders({
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      })
    }).pipe(
      map(response => {
        console.log('✅ Policy summary received:', response);
        return response;
      }),
      catchError(error => {
        console.error('❌ Get policy summary failed:', error);
        return throwError(() => ({
          userMessage: this.getUserFriendlyErrorMessage(error),
          originalError: error
        }));
      })
    );
  }

  // ==================== HELPER METHODS ====================

  private logHeaders(headers: HttpHeaders): any {
    console.log('\n📋 === HTTP HEADERS ANALYSIS ===');
    
    const headerObj: any = {};
    const headerNames = headers.keys();
    
    if (headerNames.length === 0) {
      console.log('No headers found in response');
      return {};
    }
    
    console.log('Available headers:');
    headerNames.forEach(name => {
      const value = headers.get(name);
      headerObj[name] = value;
      console.log(`  ${name}: ${value}`);
    });
    
    return headerObj;
  }

  private getUserFriendlyErrorMessage(error: any): string {
    if (error.status === 0) {
      return 'Cannot connect to server. Please check your internet connection and try again.';
    } else if (error.status === 400) {
      return 'Invalid request. Please check your input and try again.';
    } else if (error.status === 401) {
      return 'Unauthorized access. Please login again.';
    } else if (error.status === 403) {
      return 'Access forbidden. You do not have permission to access this resource.';
    } else if (error.status === 404) {
      return 'Data not found. The requested policy may not exist.';
    } else if (error.status === 408) {
      return 'Request timeout. Please try again.';
    } else if (error.status >= 500) {
      return 'Server error occurred. Please try again later or contact support.';
    } else if (error.message) {
      return `Error: ${error.message}`;
    } else {
      return `HTTP Error ${error.status}: Please try again or contact support.`;
    }
  }

  private extractTotalFromHeaders(headers: HttpHeaders): number {
    const headerNames = [
      'X-Total-Count',
      'Total-Count', 
      'x-total-count',
      'total-count',
      'X-Total',
      'Total',
      'Count'
    ];
    
    for (const headerName of headerNames) {
      const value = headers.get(headerName);
      if (value) {
        const parsed = parseInt(value);
        if (!isNaN(parsed) && parsed >= 0) {
          console.log(`📊 Found total in header ${headerName}:`, parsed);
          return parsed;
        }
      }
    }
    
    return 0;
  }

  private processRealApiResponse(response: HttpResponse<any>, requestedPage: number, requestedPageSize: number): ApiPaginationResponse {
    console.log('🔄 Processing Real API Response...');
    
    const body = response.body;
    const headers = response.headers;
    
    let data: any[] = [];
    let totalRecords = 0;
    let currentPage = requestedPage;
    let pageSize = requestedPageSize;

    // Extract total count from headers
    const totalFromHeaders = this.extractTotalFromHeaders(headers);
    
    console.log('🔍 Response Analysis:', {
      'X-Total-Count': headers.get('X-Total-Count'),
      'Total-Count': headers.get('Total-Count'),
      'totalFromHeaders': totalFromHeaders,
      'responseType': typeof body,
      'isArray': Array.isArray(body)
    });

    // Process different response formats
    if (body && typeof body === 'object') {
      
      // Format 1: Standard pagination object
      if (body.data && Array.isArray(body.data)) {
        console.log('📊 Format: Standard Pagination Object');
        data = body.data;
        totalRecords = body.totalRecords || body.total || body.totalCount || body.count || totalFromHeaders || 0;
        currentPage = body.currentPage || body.page || requestedPage;
        pageSize = body.pageSize || body.size || requestedPageSize;
      }
      // Format 2: Items pagination
      else if (body.items && Array.isArray(body.items)) {
        console.log('📊 Format: Items Pagination');
        data = body.items;
        totalRecords = body.totalCount || body.totalRecords || body.total || totalFromHeaders || 0;
      }
      // Format 3: Direct array
      else if (Array.isArray(body)) {
        console.log('📊 Format: Direct Array');
        data = body;
        totalRecords = totalFromHeaders || 0;
        
        // Jika tidak ada totalRecords, estimate berdasarkan data length
        if (totalRecords === 0 && data.length > 0) {
          console.warn('⚠️ No totalRecords from API, estimating...');
          
          if (data.length === pageSize) {
            // Full page suggests more data
            totalRecords = (currentPage * pageSize) + 1; // Conservative estimate
          } else {
            // Partial page suggests this is the end
            totalRecords = ((currentPage - 1) * pageSize) + data.length;
          }
          
          console.log('📊 Estimated totalRecords:', totalRecords);
        }
      }
      // Format 4: Unknown structure
      else {
        console.log('📊 Format: Unknown - searching for data arrays');
        
        const possibleDataArrays = Object.entries(body).filter(([key, value]) => Array.isArray(value));
        if (possibleDataArrays.length > 0) {
          const [dataKey, dataValue] = possibleDataArrays[0];
          data = dataValue as any[];
          totalRecords = this.extractTotalFromBody(body) || totalFromHeaders || 0;
          console.log(`Using: ${dataKey}[${data.length}] records`);
        }
      }
    } else {
      console.error('❌ Invalid API response format');
      throw new Error('Invalid API response format: ' + typeof body);
    }

    // Calculate pagination metadata
    const totalPages = totalRecords > 0 ? Math.ceil(totalRecords / pageSize) : 0;
    const hasNextPage = totalRecords > 0 && currentPage < totalPages;
    const hasPreviousPage = currentPage > 1;

    console.log('\n📊 === FINAL PAGINATION RESULT ===');
    console.log('Data records:', data.length);
    console.log('Total records:', totalRecords);
    console.log('Current page:', currentPage);
    console.log('Page size:', pageSize);
    console.log('Total pages:', totalPages);
    console.log('Has next page:', hasNextPage);
    console.log('Has previous page:', hasPreviousPage);

    const result: ApiPaginationResponse = {
      data,
      totalRecords,
      currentPage,
      pageSize,
      totalPages,
      hasNextPage,
      hasPreviousPage
    };

    return result;
  }

  private extractTotalFromBody(body: any): number {
    const totalKeys = [
      'totalRecords',
      'total',
      'totalCount',
      'count',
      'totalItems',
      'totalElements',
      'totalSize',
      'recordCount'
    ];
    
    for (const key of totalKeys) {
      if (body[key] !== undefined && body[key] !== null) {
        const value = parseInt(body[key]);
        if (!isNaN(value) && value >= 0) {
          console.log(`📊 Found total in body.${key}:`, value);
          return value;
        }
      }
    }
    
    return 0;
  }
}
