// components/login/login.component.ts
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService, LoginRequest, Company } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
  // HAPUS SEMUA BARIS INI JIKA ADA:
  // standalone: true,
  // imports: [CommonModule, FormsModule, RouterModule]
})
export class LoginComponent implements OnInit {
  loginForm: LoginRequest = {
    username: '',
    password: '',
    company: ''
  };
  
  companies: Company[] = [];
  errorMessage: string = '';
  isLoading: boolean = false;

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit(): void {
    if (this.authService.isLoggedIn()) {
      this.router.navigate(['/dashboard']);
      return;
    }
    
    this.loadCompanies();
  }

  loadCompanies(): void {
    this.authService.getCompanies().subscribe({
      next: (companies) => {
        this.companies = companies;
      },
      error: (error) => {
        console.error('Error loading companies:', error);
        this.errorMessage = 'Gagal memuat data company';
      }
    });
  }

  onSubmit(): void {
    if (!this.loginForm.username?.trim() || 
        !this.loginForm.password?.trim() || 
        !this.loginForm.company?.trim()) {
      this.errorMessage = 'Mohon lengkapi semua field';
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';

    this.authService.login(this.loginForm).subscribe({
      next: (response) => {
        this.isLoading = false;
        if (response.success) {
          this.authService.setCurrentUser({
            userID: response.userID,
            companyID: response.companyID
          });
          
          const redirectUrl = this.authService.getRedirectUrl();
          this.router.navigateByUrl(redirectUrl);
        } else {
          this.errorMessage = response.message || 'Login gagal';
        }
      },
      error: (error) => {
        this.isLoading = false;
        console.error('Login error:', error);
        
        if (error.status === 500) {
          this.errorMessage = 'Terjadi kesalahan pada server';
        } else if (error.status === 0) {
          this.errorMessage = 'Tidak dapat terhubung ke server';
        } else {
          this.errorMessage = 'Terjadi kesalahan saat login';
        }
      }
    });
  }

  clearErrorMessage(): void {
    if (this.errorMessage) {
      this.errorMessage = '';
    }
  }
}
