import { Component, OnInit } from '@angular/core';
import { PolicyService, ApiPaginationResponse,  } from '../../services/policy.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-consolidate-policy',
  standalone: false,
  templateUrl: './consolidate-policy.component.html',
  styleUrls: ['./consolidate-policy.component.scss']
})
// components/consolidate-policy/consolidate-policy.component.ts

export class ConsolidatePolicyComponent implements OnInit {
  // Properties
policies: any[] = [];
  searchForm = {
    policyId: '',
    appNo: ''
  };
  
  currentPage = 1;
  pageSize = 10;
  pageSizes = [10, 25, 50, 100];
  totalPages = 0;
  totalRecords = 0;
  hasNextPage = true;
  hasPreviousPage = true;
  isLoading = true;
  errorMessage = '';
  lastApiCall = '';
  apiResponseTime = 0;
  
  // CHANGE: Make these properties public (remove 'private')
  previousPageSize: number = 10;
  isPageSizeChanging = false; // Remove 'private' keyword

  constructor(
    private policyService: PolicyService,
    private router: Router
  ) {}
 

  ngOnInit(): void {
    console.log('🚀 ConsolidatePolicyComponent initialized');
    this.previousPageSize = this.pageSize;
    this.loadPoliciesFromAPI();
  }

  // ENHANCED: Page Size Change yang tidak menghilangkan next page
  onPageSizeChange(): void {
    console.log('📏 Page size change started:', {
      from: this.previousPageSize,
      to: this.pageSize,
      currentState: {
        currentPage: this.currentPage,
        totalPages: this.totalPages,
        totalRecords: this.totalRecords,
        hasNextPage: this.hasNextPage
      }
    });

    this.isPageSizeChanging = true; // Set flag
    
    // Calculate current record position to maintain context
    const currentRecordStart = ((this.currentPage - 1) * this.previousPageSize) + 1;
    
    // Calculate new page to show same record area
    const newPage = Math.max(1, Math.ceil(currentRecordStart / this.pageSize));
    
    console.log('📊 Page size calculation:', {
      currentRecordStart,
      newPage,
      calculation: `${currentRecordStart} / ${this.pageSize} = ${newPage}`
    });
    
    // Update page BEFORE loading data
    this.currentPage = newPage;
    
    // Store current page size as previous for next change
    this.previousPageSize = this.pageSize;
    
    // Load data with new parameters
    this.loadPoliciesWithPageSizeChange();
  }

  private loadPoliciesWithPageSizeChange(): void {
    const startTime = Date.now();
    this.isLoading = true;
    // IMPORTANT: Don't clear error message or pagination state during page size change
    
    console.log('\n📡 === PAGE SIZE CHANGE API CALL ===');
    console.log('Request params:', {
      page: this.currentPage,
      pageSize: this.pageSize,
      maintainedTotalRecords: this.totalRecords, // Keep existing total for reference
      isPageSizeChange: true
    });
    
    const policyId = this.searchForm.policyId.trim() || undefined;
    const appNo = this.searchForm.appNo.trim() || undefined;
    
    this.lastApiCall = new Date().toLocaleTimeString();
    
    this.policyService.getConsolidatePolicies(policyId, appNo, this.currentPage, this.pageSize)
      .subscribe({
        next: (response: any) => {
          this.apiResponseTime = Date.now() - startTime;
          console.log('✅ Page size change API success:', response);
          
          // Process response with special handling for page size change
          this.processPageSizeChangeResponse(response);
          
          this.isLoading = false;
          this.isPageSizeChanging = false; // Reset flag
          this.validateNextPageAvailability();
        },
        error: (error: any) => {
          console.error('❌ Page size change API error:', error);
          this.handlePageSizeChangeError(error);
        }
      });
  }

  private processPageSizeChangeResponse(response: any): void {
    console.log('🔄 Processing page size change response...');
    
    // Update policies data
    this.policies = response.data || response.items || response || [];
    
    // CRITICAL: Maintain or update total records intelligently
    const newTotalRecords = response.totalRecords || response.total || response.totalCount || 0;
    
    if (newTotalRecords > 0) {
      // Use API provided total
      this.totalRecords = newTotalRecords;
    } else if (this.totalRecords > 0) {
      // Keep existing total if API doesn't provide it
      console.log('📊 Maintaining existing totalRecords:', this.totalRecords);
    } else if (this.policies.length > 0) {
      // Estimate if no existing total
      this.estimateTotalRecords();
    }
    
    // Recalculate pagination with maintained total
    this.recalculatePaginationState();
    
    console.log('📊 Page size change result:', {
      policiesLoaded: this.policies.length,
      totalRecords: this.totalRecords,
      totalPages: this.totalPages,
      currentPage: this.currentPage,
      hasNextPage: this.hasNextPage,
      pageSize: this.pageSize
    });
  }

  private estimateTotalRecords(): void {
    // Conservative estimation
    if (this.policies.length === this.pageSize) {
      // Full page suggests more data available
      this.totalRecords = Math.max(this.totalRecords, (this.currentPage * this.pageSize) + 1);
    } else {
      // Partial page suggests this might be the end
      this.totalRecords = Math.max(this.totalRecords, ((this.currentPage - 1) * this.pageSize) + this.policies.length);
    }
    console.log('📊 Estimated totalRecords:', this.totalRecords);
  }

  private recalculatePaginationState(): void {
    if (this.totalRecords > 0 && this.pageSize > 0) {
      this.totalPages = Math.ceil(this.totalRecords / this.pageSize);
      this.hasNextPage = this.currentPage < this.totalPages;
      this.hasPreviousPage = this.currentPage > 1;
      
      // Adjust current page if it exceeds total pages
      if (this.currentPage > this.totalPages) {
        this.currentPage = Math.max(1, this.totalPages);
        this.hasNextPage = false;
      }
    } else {
      this.totalPages = 1;
      this.hasNextPage = false;
      this.hasPreviousPage = false;
    }
  }

  private handlePageSizeChangeError(error: any): void {
    console.error('Handling page size change error:', error);
    this.isLoading = false;
    this.isPageSizeChanging = false;
    
    // Don't clear pagination state on error - maintain existing state
    this.errorMessage = 'Failed to change page size: ' + (error.message || 'Unknown error');
    
    // Keep existing pagination intact
    console.log('Maintaining pagination state due to page size change error');
  }

  private validateNextPageAvailability(): void {
    console.log('\n🔍 === NEXT PAGE VALIDATION ===');
    
    const validation = {
      hasData: this.policies.length > 0,
      hasTotalRecords: this.totalRecords > 0,
      hasTotalPages: this.totalPages > 0,
      currentPageValid: this.currentPage >= 1 && this.currentPage <= this.totalPages,
      nextPageCalculation: this.currentPage < this.totalPages,
      actualHasNext: this.hasNextPage
    };
    
    console.log('Next page validation:', validation);
    
    // Fix inconsistencies
    if (validation.hasTotalRecords && validation.hasTotalPages) {
      const shouldHaveNext = validation.nextPageCalculation;
      if (this.hasNextPage !== shouldHaveNext) {
        console.log('🔧 Fixing hasNextPage inconsistency');
        this.hasNextPage = shouldHaveNext;
      }
    }
    
    // Ensure next page is available when it should be
    if (this.totalRecords > (this.currentPage * this.pageSize)) {
      this.hasNextPage = true;
      console.log('🔧 Ensured hasNextPage = true based on record count');
    }
  }

  // REGULAR API LOAD (for search, initial load, etc)
  loadPoliciesFromAPI(): void {
    if (this.isPageSizeChanging) {
      console.log('⏳ Page size change in progress, skipping regular load');
      return;
    }

    const startTime = Date.now();
    this.isLoading = true;
    this.errorMessage = '';
    
    console.log('\n📡 === REGULAR API CALL ===');
    console.log('Request Parameters:', {
      page: this.currentPage,
      pageSize: this.pageSize,
      policyId: this.searchForm.policyId || 'none',
      appNo: this.searchForm.appNo || 'none'
    });
    
    const policyId = this.searchForm.policyId.trim() || undefined;
    const appNo = this.searchForm.appNo.trim() || undefined;
    
    this.lastApiCall = new Date().toLocaleTimeString();
    
    this.policyService.getConsolidatePolicies(policyId, appNo, this.currentPage, this.pageSize)
      .subscribe({
        next: (response: any) => {
          this.apiResponseTime = Date.now() - startTime;
          console.log('✅ Regular API success:', response);
          
          // Regular response processing
          this.processRegularApiResponse(response);
          
          this.isLoading = false;
        },
        error: (error: any) => {
          this.apiResponseTime = Date.now() - startTime;
          console.error('❌ Regular API error:', error);
          this.handleRegularApiError(error);
        }
      });
  }

  private processRegularApiResponse(response: any): void {
    this.policies = response.data || response.items || response || [];
    this.totalRecords = response.totalRecords || response.total || response.totalCount || 0;
    this.totalPages = response.totalPages || Math.ceil(this.totalRecords / this.pageSize) || 0;
    this.hasNextPage = response.hasNextPage ?? (this.currentPage < this.totalPages);
    this.hasPreviousPage = response.hasPreviousPage ?? (this.currentPage > 1);
    this.currentPage = response.currentPage || this.currentPage;
    this.pageSize = response.pageSize || this.pageSize;

    // Fallback calculations if API doesn't provide complete pagination
    if (this.totalRecords > 0 && this.totalPages === 0) {
      this.totalPages = Math.ceil(this.totalRecords / this.pageSize);
      this.hasNextPage = this.currentPage < this.totalPages;
      this.hasPreviousPage = this.currentPage > 1;
    }
  }

  private handleRegularApiError(error: any): void {
    this.policies = [];
    this.isLoading = false;
    
    if (error.status === 0) {
      this.errorMessage = 'Cannot connect to API server. Please check if backend is running.';
    } else if (error.status === 404) {
      this.errorMessage = 'API endpoint not found.';
    } else {
      this.errorMessage = `API Error: ${error.message || 'Unknown error'}`;
    }
  }

  // PAGINATION NAVIGATION METHODS
  canGoNext(): boolean {
    return this.hasNextPage && !this.isLoading && this.totalPages > 0 && this.currentPage < this.totalPages;
  }

  canGoPrevious(): boolean {
    return this.hasPreviousPage && !this.isLoading && this.currentPage > 1;
  }

  canGoToFirst(): boolean {
    return this.currentPage > 1 && !this.isLoading;
  }

  canGoToLast(): boolean {
    return this.hasNextPage && !this.isLoading && this.totalPages > 0 && this.currentPage < this.totalPages;
  }

  goToNextPage(): void {
    console.log('🔄 Next page requested');
    if (this.canGoNext()) {
      this.onPageChange(this.currentPage + 1);
    } else {
      console.warn('Cannot go to next page:', {
        hasNextPage: this.hasNextPage,
        isLoading: this.isLoading,
        currentPage: this.currentPage,
        totalPages: this.totalPages
      });
    }
  }

  goToPreviousPage(): void {
    if (this.canGoPrevious()) {
      this.onPageChange(this.currentPage - 1);
    }
  }

  goToFirstPage(): void {
    if (this.canGoToFirst()) {
      this.onPageChange(1);
    }
  }

  goToLastPage(): void {
    if (this.canGoToLast()) {
      this.onPageChange(this.totalPages);
    }
  }

  onPageChange(page: number): void {
    if (page < 1 || (page > this.totalPages && this.totalPages > 0) || page === this.currentPage || this.isLoading) {
      return;
    }
    
    console.log('📄 Page change:', this.currentPage, '->', page);
    this.currentPage = page;
    this.loadPoliciesFromAPI();
  }

  // UTILITY METHODS
  getPageNumbers(): number[] {
    const pages: number[] = [];
    
    if (this.totalPages <= 0) return pages;
    
    const maxPagesToShow = 7;
    
    if (this.totalPages <= maxPagesToShow) {
      for (let i = 1; i <= this.totalPages; i++) {
        pages.push(i);
      }
    } else {
      // Show pages around current page
      const startPage = Math.max(1, this.currentPage - 3);
      const endPage = Math.min(this.totalPages, this.currentPage + 3);
      
      if (startPage > 1) {
        pages.push(1);
        if (startPage > 2) pages.push(-1);
      }
      
      for (let i = startPage; i <= endPage; i++) {
        pages.push(i);
      }
      
      if (endPage < this.totalPages) {
        if (endPage < this.totalPages - 1) pages.push(-1);
        pages.push(this.totalPages);
      }
    }
    
    return pages;
  }

  getStartRecord(): number {
    return Math.max(1, (this.currentPage - 1) * this.pageSize + 1);
  }

  getEndRecord(): number {
    return Math.min(this.currentPage * this.pageSize, this.totalRecords);
  }

  formatDate(date: any): string {
    if (!date) return '-';
    try {
      return new Date(date).toLocaleDateString('id-ID');
    } catch {
      return '-';
    }
  }

  formatNumber(num: any): string {
    if (num == null || isNaN(num)) return '0';
    return num.toLocaleString('id-ID');
  }

  // OTHER METHODS
  onSearch(): void {
    console.log('🔍 Search triggered');
    this.currentPage = 1;
    this.loadPoliciesFromAPI();
  }

  onClearSearch(): void {
    this.searchForm = { policyId: '', appNo: '' };
    this.currentPage = 1;
    this.loadPoliciesFromAPI();
  }

  reloadData(): void {
    this.loadPoliciesFromAPI();
  }

  viewPolicyDetail(policyId: string): void {
    this.router.navigate(['/dashboard/policy-detail', policyId]);
  }

  trackByPolicyId(index: number, policy: any): any {
    return policy.policyID || index;
  }

  Math = Math;
}
