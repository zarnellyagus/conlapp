// components/dashboard/dashboard.component.ts
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-dashboard',
  standalone: false,
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  currentUser: any;
  menus: any[] = [];
  sidebarCollapsed = false;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.currentUser = this.authService.getCurrentUser();
    if (!this.currentUser) {
      this.router.navigate(['/login']);
      return;
    }
    
    this.loadUserMenus();
  }

  loadUserMenus(): void {
    this.authService.getUserMenus(this.currentUser.userID, this.currentUser.companyID)
      .subscribe({
        next: (menus) => {
          this.menus = menus;
        },
        error: (error) => {
          console.error('Error loading menus:', error);
        }
      });
  }

  toggleSidebar(): void {
    this.sidebarCollapsed = !this.sidebarCollapsed;
  }

  // TAMBAHKAN: Method untuk dropdown menu items
  viewProfile(event: Event): void {
    event.preventDefault();
    // TODO: Navigate to profile page atau buka modal profile
    console.log('View profile clicked');
    // this.router.navigate(['/dashboard/profile']);
  }

  openSettings(event: Event): void {
    event.preventDefault();
    // TODO: Navigate to settings page atau buka modal settings
    console.log('Settings clicked');
    // this.router.navigate(['/dashboard/settings']);
  }

  openHelp(event: Event): void {
    event.preventDefault();
    // TODO: Navigate to help page atau buka modal help
    console.log('Help clicked');
    // this.router.navigate(['/dashboard/help']);
  }

  logout(event?: Event): void {
    if (event) {
      event.preventDefault();
    }
    
    // Confirm logout
    if (confirm('Apakah Anda yakin ingin logout?')) {
      this.authService.logout();
      this.router.navigate(['/login']);
    }
  }
}
