// components/policy-detail/policy-detail.component.ts

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PolicyService, PolicyDetail, EpolicyInfo, PolicySummary } from '../../services/policy.service';

@Component({
  selector: 'app-policy-detail',
  standalone: false,
  templateUrl: './policy-detail.component.html',
  styleUrls: ['./policy-detail.component.scss']
})
export class PolicyDetailComponent implements OnInit {
  policyId: string = '';
  activeTab: string = 'policy-info';
  
  policyDetail: PolicyDetail | null = null;
  epolicyInfo: EpolicyInfo | null = null;
  policySummary: PolicySummary | null = null;
  
  isLoading = false;
  errorMessage: string = '';

  // Individual loading states
  isLoadingPolicyDetail = false;
  isLoadingEpolicy = false;
  isLoadingPolicySummary = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private policyService: PolicyService
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.policyId = params['id'];
      if (this.policyId) {
        console.log('Loading policy data for ID:', this.policyId);
        this.loadAllData();
      } else {
        this.errorMessage = 'Policy ID not found in route parameters';
        this.router.navigate(['/dashboard/consolidate-policy']);
      }
    });
  }

  // Format methods
  formatDate(date: any): string {
    if (!date) return '-';
    
    try {
      const d = new Date(date);
      if (isNaN(d.getTime())) return '-';
      
      const day = d.getDate().toString().padStart(2, '0');
      const month = (d.getMonth() + 1).toString().padStart(2, '0');
      const year = d.getFullYear();
      
      return `${day}/${month}/${year}`;
    } catch (error) {
      console.error('Error formatting date:', error);
      return '-';
    }
  }

  formatDateTime(date: any): string {
    if (!date) return '-';
    
    try {
      const d = new Date(date);
      if (isNaN(d.getTime())) return '-';
      
      const day = d.getDate().toString().padStart(2, '0');
      const month = (d.getMonth() + 1).toString().padStart(2, '0');
      const year = d.getFullYear();
      const hours = d.getHours().toString().padStart(2, '0');
      const minutes = d.getMinutes().toString().padStart(2, '0');
      
      return `${day}/${month}/${year} ${hours}:${minutes}`;
    } catch (error) {
      console.error('Error formatting datetime:', error);
      return '-';
    }
  }

  formatNumber(num: any): string {
    if (num == null || isNaN(num)) return '-';
    return num.toLocaleString('id-ID');
  }

  formatCurrency(amount: any): string {
    if (amount == null || isNaN(amount)) return 'Rp -';
    return 'Rp ' + amount.toLocaleString('id-ID');
  }

  // Load data methods - API ONLY
  loadAllData(): void {
    this.isLoading = true;
    this.errorMessage = '';
    
    // Load all data concurrently
    this.loadPolicyDetail();
    this.loadEpolicyInfo();
    this.loadPolicySummary();
  }

  loadPolicyDetail(): void {
    this.isLoadingPolicyDetail = true;
    
    this.policyService.getPolicyDetail(this.policyId).subscribe({
      next: (detail: PolicyDetail) => {
        this.policyDetail = detail;
        this.isLoadingPolicyDetail = false;
        this.checkAllLoadingComplete();
        console.log('✅ Policy detail loaded from API:', detail);
      },
      error: (error: any) => {
        console.error('❌ Error loading policy detail from API:', error);
        this.isLoadingPolicyDetail = false;
        this.checkAllLoadingComplete();
        
        // Show specific error for policy detail
        if (!this.errorMessage) {
          this.errorMessage = error.userMessage || 'Failed to load policy detail from API';
        }
      }
    });
  }

  loadEpolicyInfo(): void {
    this.isLoadingEpolicy = true;
    
    this.policyService.getEpolicyInfo(this.policyId).subscribe({
      next: (info: EpolicyInfo) => {
        this.epolicyInfo = info;
        this.isLoadingEpolicy = false;
        console.log('✅ E-policy info loaded from API:', info);
      },
      error: (error: any) => {
        console.error('❌ Error loading e-policy info from API:', error);
        this.epolicyInfo = null;
        this.isLoadingEpolicy = false;
        // Don't set main error message for epolicy failure
      }
    });
  }

  loadPolicySummary(): void {
    this.isLoadingPolicySummary = true;
    
    this.policyService.getPolicySummary(this.policyId).subscribe({
      next: (summary: PolicySummary) => {
        this.policySummary = summary;
        this.isLoadingPolicySummary = false;
        console.log('✅ Policy summary loaded from API:', summary);
      },
      error: (error: any) => {
        console.error('❌ Error loading policy summary from API:', error);
        this.policySummary = null;
        this.isLoadingPolicySummary = false;
        // Don't set main error message for summary failure
      }
    });
  }

  private checkAllLoadingComplete(): void {
    if (!this.isLoadingPolicyDetail && !this.isLoadingEpolicy && !this.isLoadingPolicySummary) {
      this.isLoading = false;
    }
  }

  // UI interaction methods
  setActiveTab(tab: string): void {
    this.activeTab = tab;
    console.log('Active tab changed to:', tab);
  }

  goBack(): void {
    console.log('Navigating back to consolidate policy list');
    this.router.navigate(['/dashboard/consolidate-policy']);
  }

  refreshData(): void {
    console.log('Refreshing all policy data from API...');
    this.loadAllData();
  }

  // Utility methods
  hasData(): boolean {
    return !!(this.policyDetail || this.epolicyInfo || this.policySummary);
  }

  hasAnyLoadingError(): boolean {
    return !!this.errorMessage;
  }

  isAnyLoading(): boolean {
    return this.isLoadingPolicyDetail || this.isLoadingEpolicy || this.isLoadingPolicySummary;
  }

  getLoadingMessage(): string {
    const loadingItems = [];
    if (this.isLoadingPolicyDetail) loadingItems.push('Policy Details');
    if (this.isLoadingEpolicy) loadingItems.push('E-Policy Info');
    if (this.isLoadingPolicySummary) loadingItems.push('Policy Summary');
    
    if (loadingItems.length === 0) return '';
    
    return `Loading ${loadingItems.join(', ')} from API...`;
  }

  getPolicyStatusClass(): string {
    if (!this.policyDetail?.policyStatus) return 'text-muted';
    
    const status = this.policyDetail.policyStatus.toLowerCase();
    if (status === 'active') return 'text-success';
    if (status === 'inactive' || status === 'lapsed') return 'text-danger';
    if (status === 'pending') return 'text-warning';
    
    return 'text-muted';
  }

  getEpolicyStatusClass(): string {
    if (!this.epolicyInfo?.epolicyStatus) return 'text-muted';
    
    const status = this.epolicyInfo.epolicyStatus.toLowerCase();
    if (status === 'generated' || status === 'active') return 'text-success';
    if (status === 'pending') return 'text-warning';
    if (status === 'expired' || status === 'inactive') return 'text-danger';
    
    return 'text-muted';
  }

  getPolicyStatusBadgeClass(): string {
    if (!this.policyDetail?.policyStatus) return 'bg-secondary';
    
    const status = this.policyDetail.policyStatus.toLowerCase();
    if (status === 'active') return 'bg-success';
    if (status === 'inactive' || status === 'lapsed') return 'bg-danger';
    if (status === 'pending') return 'bg-warning';
    
    return 'bg-secondary';
  }

  getEpolicyStatusBadgeClass(): string {
    if (!this.epolicyInfo?.epolicyStatus) return 'bg-secondary';
    
    const status = this.epolicyInfo.epolicyStatus.toLowerCase();
    if (status === 'generated' || status === 'active') return 'bg-success';
    if (status === 'pending') return 'bg-warning';
    if (status === 'expired' || status === 'inactive') return 'bg-danger';
    
    return 'bg-secondary';
  }
}
