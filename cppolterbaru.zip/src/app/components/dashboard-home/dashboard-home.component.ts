// components/dashboard-home/dashboard-home.component.ts
import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-dashboard-home',
  standalone: false,
  templateUrl: './dashboard-home.component.html',
  styleUrls: ['./dashboard-home.component.scss']
})
export class DashboardHomeComponent implements OnInit {
  currentUser: any;
  stats = {
    totalPolicies: 1234,
    activePolicies: 987,
    pendingPolicies: 45
  };

  constructor(private authService: AuthService) {}

  ngOnInit(): void {
    this.currentUser = this.authService.getCurrentUser();
    this.loadDashboardStats();
  }

  loadDashboardStats(): void {
    // TODO: Implementasi untuk load dashboard statistics dari API
    console.log('Loading dashboard stats...');
  }
}
